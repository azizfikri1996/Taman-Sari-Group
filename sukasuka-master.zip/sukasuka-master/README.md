# sukasuka

<a href="https://lgtm.com/projects/g/AppLoidx/sukasuka/context:javascript"><img alt="Language grade: JavaScript" src="https://img.shields.io/lgtm/grade/javascript/g/AppLoidx/sukasuka.svg?logo=lgtm&logoWidth=18"/></a>

### Screenshot

![](assets/img/screenshot.png)

OST from page: [Call You - Tamaru Yamada](https://www.youtube.com/watch?v=Wml7YAGYTac)
